﻿$(document).ready(function () {
    $('#shiftinfo').tooltip({
        track: true,
        delay: 0,
        showURL: false,
        bodyHandler: function () {
            return $('#shifts').html();
        }
    });

    $('.datepicker').datepicker("option", "onSelect", function (dateText, inst) {
        $.getJSON(_global.root + 'api/shift/getshiftbydate', { employeeId: _global.employeeId, date: dateText },
        function (data) {
            if (data != null) {
                $('#shiftOfDate').text(data.Name);
                $('#FromShiftName').val(data.Name);
                $('#FromShift').val(data.Id);
                $('input[type=submit]').show();
            }
            else {
                $('#shiftOfDate').text('OFF');
                $('#FromShiftName').val('OFF');
                $('#FromShift').val('');
                $('input[type=submit]').hide();
            }
        });
    });

    //Process redirect to My change shift request.
    var successed = $("#successed").val();
    var year = $("#year").val();
    if (successed == "true") {

        confirm('Successfull!\nPress OK to continue', function () {
            document.location = _global.root + "ChangeShift/EmployeeView/" + year;
        });
    }
});