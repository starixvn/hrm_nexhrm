﻿var leaveTypeId = null;

$(document).ready(function () {
    var successed = $("#successed").val();
    var year = $("#year").val();
    if (successed == "true") {
        confirm('Successfull!\nPress OK to continue', function () {
            document.location = _global.root + "Leave/EmployeeView/" + year;
        });
    }

    bindHalfDay();
    $('#LeaveTypeId').change(function () {
        bindHalfDay();
    });

    $('#FromDate').datepicker("option", "onSelect", function (dateText, inst) {
        if (leaveTypeId == 16) {
            $.getJSON(_global.root + 'api/shift/getshiftbydate', { employeeId: _global.employeeId, date: dateText },
                function (response) {
                    if (response != null) {
                        $('#FromTime').val(response.BeginCheckInTime);
                        $('#ToTime').val(response.BeginCheckOutTime);
                    }
                }
            );
        }
    });

    $("#FromDate, #ToDate").change(function () {
        var totalDays = 0;
        var fromStr = $("#FromDate").val();
        var dat = Date.parse(fromStr);
        var fromDate = new Date(dat);
        var from = fromDate.getTime();

        var toStr = $("#ToDate").val();
        dat = Date.parse(toStr);
        var toDate = new Date(dat);
        var to = toDate.getTime();
        totalDays = parseInt((to - from) / (24 * 3600 * 1000)) + 1;

        //Exclude the weekend

        if (totalDays >= 7) {
            totalDays = totalDays - parseInt(totalDays / 7) * 2;
        }
        else {
            if ((totalDays > 3 && fromDate.getDay() >= 4) || (totalDays == 6 && fromDate.getDay() == 3)) {
                totalDays = totalDays - 2;
            }
            if (fromDate.getDay == 0 || fromDate.getDay == 6 || toDate.getDay() == 0 || toDate.getDay() == 6) {
                totalDays = totalDays - 1;
            }
        }

        $("#TotalDays").val(totalDays.toString());
    });
});

function bindHalfDay() {
    leaveTypeId = parseInt($('#LeaveTypeId').val());
    if (leaveTypeId == 16) {
        //get shift information
        $.getJSON(_global.root + 'api/shift/getshiftbydate',
            { employeeId: _global.employeeId, date: $('#FromDate').val() },
            function (response) {
                if (response != null) {
                    $('#FromTime').val(response.BeginCheckInTime);
                    $('#ToTime').val(response.BeginCheckOutTime);
                }
            });

        $('#ToDate').val($('#FromDate').val());
        $('.time').show();
        $('#TotalDays').val('0.5').prop('readonly', true);
        $('#ToDate').prop('readonly', true).datepicker('disable').prop('disabled', false);
    }
    else {
        $('.time').hide();
        $('#TotalDays').prop('readonly', false);
        $('#ToDate').prop('readonly', false).datepicker('enable');
    }
}