﻿function deleteMemo(id) {

    confirm('Are you sure you want to delete this memo?', function () {
        $.post(_global.root + 'ajax/deletememo', { id: id }, function (data) {
            $('#row_' + id).remove();
            autoIndex();
        });

    });
}

//function autoIndex() {
//    var index = 0;
//    $('tr').each(function () {
//        $(this).children("td").eq(0).html(index);
//        index = index + 1;
//    });
//}
