﻿$(document).ready(function () {
    // menu
    bindMenu('.Pending', 'pendingMenu');
    bindMenu('.Approved', 'approvedMenu');
});

function processRequest(command, eventElement) {
    var requestId = $(eventElement).attr('requestId');

    $.post(_global.root + 'ajax/processrequest',
    { command: command, id: requestId },
        function (response) {
        });

    $(eventElement).removeClass().destroyContextMenu();
    switch (command) {
        case 'Approve':
            $(eventElement).text('Approved').addClass('Approved');
            bindProcessedInfo(eventElement, 'Approve');
            bindMenu(eventElement, 'approvedMenu');
            break;
        case 'Reject':
            $(eventElement).text('Rejected').addClass('Rejected');
            bindProcessedInfo(eventElement, 'Reject');
            break;
        case 'Disapprove':
            $(eventElement).text('Pending').addClass('Pending');
            bindProcessedInfo(eventElement, 'Disapprove');
            bindMenu(eventElement, 'pendingMenu');
            break;
    }
}

function bindMenu(element, menu) {
    $(element).contextMenu({
        menu: menu
    },
    function (command, eventElement) {
        switch (command) {
            case 'Approve':
                confirm('Are you sure you want to Approve?', function () {
                    processRequest(command, eventElement);
                });

                break;
            case 'Reject':
                confirm('Are you sure you want to Reject?', function () {
                    processRequest(command, eventElement);
                });
                break;
            case 'Disapprove':
                confirm('Are you sure you want to Disapprove?', function () {
                    processRequest(command, eventElement);
                });
                break;
        }
    });
}

function bindProcessedInfo(element, type) {
    var now = new Date();
    var msg;
    var id = $(element).attr('requestid');

    msg = _global.nickName + ", " + now.format('dd mmm yyyy- HH') + 'h' + now.format('MM\'');
    $("#pb" + id).text(msg);
                
}