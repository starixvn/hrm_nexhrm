﻿$(document).ready(function () {
    initEditor('Contents','basic');

    $("#SentDate").datepicker({
        changeMonth: true,
        changeYear: true
    });
    var refNo = $("#RefNo").val();
    var subJect = $("#Subject").val();
    var forInfo = $("#ForInfo").val();
    var sentDate = $("#SentDate").val();
    var sentTo = $("#SentTo").val();
    var sentFrom = $("#SentFrom").val();
    var contents = $("#Contents").val();

    $("#btnClear").click(function () {
        $("#RefNo").val(refNo);
        $("#Subject").val(subJect);
        $("#ForInfo").val(forInfo);
        $("#SentDate").val(sentDate);
        $("#SentTo").val(sentTo);
        $("#SentFrom").val(sentFrom);
        $("#Contents").val(contents);
    });
});


