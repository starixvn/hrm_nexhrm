﻿$(document).ready(function () {
    $('#shiftinfo').tooltip({
        track: true,
        delay: 0,
        showURL: false,
        bodyHandler: function () {
            return $('#shifts').html();
        }
    });

    $('.datepicker').datepicker("option", "onSelect", function (dateText, inst) {
        $.getJSON(_global.root + 'api/shift/getshiftbydate', { employeeId: _global.employeeId, date: dateText },
        function (data) {
            if (data != null) {
                $('#shiftname').text(data.Name);
                $('#Shift').val(data.Name);
                $('input[type=submit]').show();
            }
            else {
                $('#shiftname').text(_messages.notAvailable);
                $('#Shift').val(_messages.notAvailable);
                $('input[type=submit]').hide();
            }
        });
    });

    //Process redirect to Check In/Out request.
    var successed = $("#successed").val();
    var year = $("#year").val();
    if (successed == "true") {

        if (successed == "true") {
            confirm('Successfull!\nPress OK to continue', function () {
                document.location = _global.root + "checkinout/EmployeeView/" + year;
            });
        }
    }
});