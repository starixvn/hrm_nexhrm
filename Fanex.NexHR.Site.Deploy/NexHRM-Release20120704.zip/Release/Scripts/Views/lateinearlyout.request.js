﻿$(document).ready(function () {

    //Process redirect to My late in/earlt out request.
    var successed = $("#successed").val();
    var year = $("#year").val();
    if (successed == "true") {
        confirm('Successfull!\nPress OK to continue', function(){
            document.location = _global.root + "LateInEarlyOut/EmployeeView/" + year;
        });
    }
});