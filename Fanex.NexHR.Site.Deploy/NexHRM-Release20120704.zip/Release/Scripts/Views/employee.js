﻿$(document).ready(function () {
    $('#keyword').keyup(function (event) {
        if (event.keyCode == 13) {
            query();
        }
    });

    var q = getParam('query');
    if (q != null) {
        $('#keyword').val(q);
    }

    //search onload
    query();

    $('#query').click(function (evt) {
        evt.preventDefault();
        query();
    });

});




function query() {

    var query = $('#keyword').val();
    actingButton('#query', true);

    if ($("#enable").attr("checked")) {
        enable = null;
    }
    else {
        enable = true;
    }

    $.getJSON(
    _global.root + 'api/employee/getemployees'
    , { query: query, groupId: $('#group').val(), enable: enable }
    , function (data) {
        if (data.length > 0) {
            rowIndex = 1;

            $('#data tbody').children().remove();
            $('#itemTemplate').tmpl(data).appendTo('#data');

        }
        else {
            $('#data tbody').children().remove();
            $(noInformation(12)).appendTo('#data');
        }
        reloadButtonText('#query');
    }).error(function () {
        reloadButtonText('#query');
        alert(_messages.errorTryAgain);
    });
    $('#keyword').focus().select();
}

var rowIndex = 1;
function index() {
    return rowIndex++;
}