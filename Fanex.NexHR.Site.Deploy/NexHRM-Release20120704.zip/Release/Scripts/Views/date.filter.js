﻿$(document).ready(function () {
//    var fromDate = new DatePicker("#FromDate");
//    var toDate = new DatePicker("#ToDate");

    $("#Date").change(function () {
        setDateTimeRange($(this).val());
        $("#DateOption").attr("value", $(this).val());
    });

    $("#Date").val($("#DateOption").val());
    $("#FromDate, #ToDate").change(function () {
        $("#Date").val("0");
    });



    initDatePicker();
});

function initDatePicker() {
    $('#FromDate, #ToDate').keypress(function (e) {
        var tab = 9, enter = 13;
        if (e.keyCode == tab || e.keyCode == enter)
            return true;
        return false;
    });
    $('#Date').val($("#DateOption").val());
    setDateTimeRange($("#DateOption").val());
}

function setDateTimeRange(selectedIndex) {
    var now = new Date();
    var fromDate = Date.parse($("#FromDate").val()).toString('dd MMMM, yyyy');
    var toDate = Date.parse($("#ToDate").val()).toString('dd MMMM, yyyy');
    var now = $('#DateTime-Now').val();

    switch (parseInt(selectedIndex)) {
        case 0: //default
            break;
        case 1: //today
            toDate = fromDate = Date.parse(now).toString('dd MMMM, yyyy');
            break;
        case 2: // yesterday
            toDate = fromDate = Date.parse(now).add(-1).days().toString('dd MMMM, yyyy');
            break;
        case 3: //current week
            fromDate = Date.parse(now).moveToDayOfWeek(0, -1).toString('dd MMMM, yyyy');
            toDate = Date.parse(now).toString('dd MMMM, yyyy');
            break;
        case 4: //last week
            fromDate = Date.parse(now).moveToDayOfWeek(0, -1).add(-7).days().toString('dd MMMM, yyyy');
            toDate = Date.parse(now).moveToDayOfWeek(0, -1).add(-1).days().toString('dd MMMM, yyyy');
            break;
        case 5: //current month
            fromDate = Date.parse(now).moveToFirstDayOfMonth().toString('dd MMMM, yyyy');
            toDate = Date.parse(now).toString('dd MMMM, yyyy');
            break;
        case 6: //last month
            fromDate = Date.parse(now).add(-1).months().moveToFirstDayOfMonth().toString('dd MMMM, yyyy');
            toDate = Date.parse(now).add(-1).months().moveToLastDayOfMonth().toString('dd MMMM, yyyy');
            break;
        case 7: //since last month
            fromDate = Date.parse(now).add(-1).months().moveToFirstDayOfMonth().toString('dd MMMM, yyyy');
            toDate = Date.parse(now).toString('dd MMMM, yyyy');
            break;
    }

    $("#FromDate").val(fromDate);
    $("#ToDate").val(toDate);
}

function DatePicker(controlId, dateFormat) {
    var seft = this;

    self.control = $(controlId);

    this.__defineGetter__('Value', function () {
        return control.val(); ;
    });

    this.__defineSetter__('Value', function (val) {
        control.val(val);
    });

    //ctor
    control.datepicker({
        changeMonth: false,
        changeYear: false,
        dateFormat: (dateFormat === undefined) ? "dd M, yy" : dateFormat.toString()
    });

    //define onchange event
    self.onchange = function (fn) {
        self.control.bind("onchange", function () {
            fn.apply(self);
        });
    };
}